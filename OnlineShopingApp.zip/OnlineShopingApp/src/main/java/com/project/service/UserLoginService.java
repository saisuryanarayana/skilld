package com.project.service;

import com.project.model.UserDTO;

public interface UserLoginService {
	public String userLogin(UserDTO userDto);
}
